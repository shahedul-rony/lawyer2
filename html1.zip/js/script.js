$("#card").flip(.front);
$("#card").flip(.back);